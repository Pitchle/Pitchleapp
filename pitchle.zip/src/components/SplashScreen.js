// SplashScreen.js
import React from 'react';

const SplashScreen = () => {
    return (
        <div className="splash-screen">
            <img src="/img/splash.gif" alt="gif"/>
        </div>
    );
};

export default SplashScreen;
