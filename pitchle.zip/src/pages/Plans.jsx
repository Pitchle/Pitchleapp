import React from 'react';
import Pricing from "../components/Pricing";

const Plans = () => {
    return (
          <Pricing/>
    );
};

export default Plans;