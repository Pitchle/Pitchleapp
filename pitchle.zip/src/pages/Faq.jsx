import React from 'react';
import FaQs from "../components/FAQs";

const Faq = () => {
    return (
        <div className={"bg-white"}>
            <FaQs/>
        </div>
    );
};

export default Faq;